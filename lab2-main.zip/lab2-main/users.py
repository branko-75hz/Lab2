import os
import random
# Se deben codificar las siguientes funciones y replicar la funcionalidad descrita en los comentarios
# Además, para la gestión de usuarios y preguntas se debe hacer uso de archivos

# Archivo donde se almacenarán los usuarios
users_file = 'data/users.txt'
# Lista que contiene a los usuarios con sesión activa
active_sessions = []

# La función recibe name y password
# Si el usuario ya existe deber retornar  "User already registered"
# Si el usuario no existe debe registrarlo y retornar  "User succesfully registered"
def registerUser(name,password):

    # Si el archivo no existe, lo creamos
    if not os.path.exists(users_file):
        with open(users_file, 'w') as file:
            pass  # Simplemente creamos el archivo vacío

    # Leer usuarios existentes
    with open(users_file, 'r') as file:
        users = file.readlines()

    # Verificar si el usuario ya está registrado
    for user in users:
        stored_name, stored_password, stored_score = user.strip().split(',')
        if stored_name == name:
            return "User already registered"

    # Registrar nuevo usuario
    with open(users_file, 'a') as file:
        file.write(f"{name},{password},{'0'}\n")

    return "User successfully registered"
            

# Función que abre o cierra una sesión
# Abre/cierra una sesión del usuario dependiendo del valor de flag 
# lo hace si el nombre de usuario y la contraseña son correctos
def openCloseSession(name, password, flag):
    
    # Leer usuarios registrados
    with open(users_file, 'r') as file:
        users = file.readlines()

    # Verificar si el usuario existe y si la contraseña es correcta
    for user in users:
        stored_name, stored_password, stored_score = user.strip().split(',')
        if stored_name == name:
            if stored_password == password:
                # Si la contraseña es correcta, abrir o cerrar sesión
                if flag:  # Abrir sesión
                    return openSession(name)
                else:  # Cerrar sesión
                    return closeSession(name)
            else:
                return "Incorrect password."

    return "User not found."

# Función para abrir sesión
def openSession(name):
    global active_sessions

    # Verificar si ya hay una sesión abierta
    if name in active_sessions:
        return "User already logged in."

    # Abrir nueva sesión
    active_sessions.append(name)
    return "Session opened successfully."

# Función para cerrar sesión
def closeSession(name):
    global active_sessions

    # Verificar si el usuario tiene una sesión abierta
    if name not in active_sessions:
        return "User not logged in."

    # Cerrar sesión
    active_sessions.remove(name)
    return "Session closed successfully."

# Función que actualiza el puntaje
# Actualiza el puntaje del usuario con el valor de score si el nombre de usuario y la contraseña 
# son correctos y si el usuario se encuentra con sesión abierta
def updateScore(name,password,score):
    new_lines = []
    user_found = False

    with open(users_file, 'r') as f:
        for user in f.readlines():
            # Validar si la línea tiene los tres campos esperados
            fields = user.strip().split(',')
            if len(fields) == 3:
                stored_name, stored_password, stored_score = fields
                
                if stored_name == name and stored_password == password:
                    new_lines.append(f"{name},{password},{score}\n")
                    user_found = True
                else:
                    new_lines.append(user)
            else:
                # Si la línea no tiene los campos correctos, podrías ignorarla o manejarla
                print(f"Línea malformada: {user}")
    
    if user_found:
        with open(users_file, 'w') as f:
            f.writelines(new_lines)
        return "Score updated successfully"
    else:
        return "User not found or invalid credentials"


# Función que lee el puntaje
# Retorna el puntaje del usuario si el nombre de usuario y la contraseña 
# son correctos y si el usuario se encuentra con sesión abierta
def getScore(name,password):
    global active_sessions

    # Verificar si el archivo de usuarios existe
    if not os.path.exists(users_file):
        return "No users registered."

    # Leer usuarios registrados
    with open(users_file, 'r') as file:
        users = file.readlines()

    # Verificar si el usuario y la contraseña son correctos
    for user in users:
        stored_name, stored_password, stored_score = user.strip().split(',')
        if stored_name == name:
            if stored_password == password:
                # Verificar si el usuario tiene una sesión activa
                if name in active_sessions:
                    return f"User {name}'s score: {stored_score}"
                else:
                    return "User does not have an active session."
            else:
                return "Incorrect password."
    
    return "User not found."
# Función que lee la lista de usuarios conectados
# retorna una lista con los usuarios conectados, solo debe devolver nombre y puntaje
# si el nombre de usuario y la contraseña  son correctos y si el usuario se encuentra con sesión abierta
def usersList(name,password):
    global active_sessions

    # Verifica si el usuario y contraseña son correctos
    if not os.path.exists(users_file):
        return "No users registered."

    #lee el archivo que contiene a los usuarios
    with open(users_file, 'r') as file:
        users = file.readlines()

    for user in users:
        stored_name, stored_password, stored_score = user.strip().split(',')
        if stored_name == name:
            if stored_password == password:
                # Si el usuario tiene sesión activa, devolvemos la lista de usuarios conectados
                connected_users = []
                for session_user in active_sessions:
                    for u in users:
                        u_name, u_password,u_score = u.strip().split(',')
                        if u_name == session_user:
                            # agrega el usuario con el nombre y el puntaje a la lista
                            connected_users.append({"name": u_name, "score": u_score})
                return connected_users
            else:
                return "Incorrect password."

    return "User not found."
            
    
# Función que genera una pregunta en una categoría cat
# retorna la pregunta si el nombre de usuario y la contraseña  son correctos y si el usuario se encuentra con sesión abierta
def question(name,password,cat):
    global active_sessions
    questions_file = 'data/questions.txt'

    # Verificar si el archivo de usuarios existe
    if not os.path.exists(users_file):
        return "No users registered."

    # Verificar si el archivo de preguntas existe
    if not os.path.exists(questions_file):
        return "No questions available."

    # Leer usuarios registrados
    with open(users_file, 'r') as file:
        users = file.readlines()

    # Verificar si el usuario y la contraseña son correctos
    for user in users:
        stored_name, stored_password, stored_score = user.strip().split(',')
        if stored_name == name:
            if stored_password == password:
                # Verificar si el usuario tiene una sesión activa
                if name in active_sessions:
                    # Leer preguntas de la categoría solicitada
                    questions = []
                    with open(questions_file, 'r') as qfile:
                        for line in qfile:
                            question_cat, question_text = line.strip().split(',',1)
                            if question_cat == str(cat):
                                questions.append(question_text)

                    # Si hay preguntas disponibles, seleccionar una al azar
                    if questions:
                        return random.choice(questions)
                    else:
                        return f"No questions available in category {cat}."
                else:
                    return "User does not have an active session."
            else:
                return "Incorrect password."
    
    return "User not found."
                
